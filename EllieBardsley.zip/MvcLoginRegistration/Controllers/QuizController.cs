﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcLoginRegistration.Models;

namespace MvcLoginRegistration.Controllers
{
    [Authorize(Roles = "Editor,Viewer")]
    public class QuizController : Controller
    {
        // GET: Quiz
        public ActionResult CreateQuiz()
        {
            return View("CreateQuiz");
        }
        [HttpPost]
        [Authorize(Roles = "Editor")]
        public ActionResult CreateQuiz(Quiz name)
        {
            if (ModelState.IsValid)
            {
                using (OurDBContext db = new OurDBContext())
                {
                    db.quiz.Add(name);
                    db.SaveChanges();
                }
                ModelState.Clear();
                ViewBag.Message = name.QuizName + " " + " successfully created.";
            }
            return View("CreateQuiz");
        }

        [Authorize(Roles = "Editor")]
        public ActionResult QuizManager()
        {
            if (Session["UserId"] != null)

            {
                using (OurDBContext db = new OurDBContext())
                {
                    return View("QuizManager");
                }
            }

            else
            {
                return RedirectToAction("Login");
            }
        }
    }
}
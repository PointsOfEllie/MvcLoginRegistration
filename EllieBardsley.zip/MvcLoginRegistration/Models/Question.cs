﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcLoginRegistration.Models
{
    public class Question
    {
        [Key]
        public int QuizId { get; set; }

        public int QuestionId { get; set; }

        public string QuestionText { get; set; }

    }
}